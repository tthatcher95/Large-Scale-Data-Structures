To run this code, you must first have g++ installed.
Then you run the command 'make' which will use the Makefile to compile.

For part A, it needs a number, and a filepath to the genome.

This code generates each 5k,10k, and 100k in one.

To run each of the homework questions:

Example: ./suffix_tree --A genome.txt

-- PART A --
1A: ./prefix_trie --A genome.txt

-- Part B --
DID NOT DO.
