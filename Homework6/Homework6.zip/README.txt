To run this code, you must first have g++ installed.
Then you run the command 'make' which will use the Makefile to compile.

For part A, it needs a number, and a filepath to the genome.

For part B, it needs a number, and a filepath to the genome.

To run each of the homework questions:

Example: ./prefix_trie --A-or-B --Number-36mers-to-generate filepath-to-genome-file

-- PART A --
1A: ./prefix_trie --A 5000 genome.txt

-- PART B --
2A: ./prefix_trie --A 1000 genome.txt
